# Postgresql

#Refer the data set chocolate_1.csv and given SQL code with solved queries
