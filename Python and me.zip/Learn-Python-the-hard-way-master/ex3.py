#!/bin/python3
#!/usr/bin/env python3

# ex3: Numbers and Math

# Print "I will now count my chickens:"
print("I will now count my chickens:")

# Print the number of hens
print("Hens", 25 + 30 / 6)
# Print the number of roosters
print("Roosters, 100 -25 * 3 % 4")
print("Roosters", 100 -25 * 3 % 4)

# Print "Now I will count the eggs:"
print("Now I will count the eggs:")

# number of eggs, Notice that '/' operator returns float value in Python3
print(3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6)

# Print "Is it true that 3 + 2 < 5 - 7?"
print("Is it true that 3 + 2 < 5 - 7?")

# Print whether 3+2 is smaller than 5-7(True or False)
print(3 + 2 < 5 - 7)

# Calculate 3+2 and print the result
print("What is 3 + 2?", 3 + 2)
# Calculate 5-7 and print the result

print("What is 5 - 7?", 5 - 7)

# Print "Oh, that's why it's False."
print("Oh, that's why it's False.")

# Print "Oh, that's why it's False."
print("How about some more.")

# Print whether 5 is greater than -2(True or False)
print("Is it greater?", 5 > -2)
# Print whether 5 is greater than or equal to -2?(True or False)
print("Is it greater or equal?", 5 >= -2)
# Print whether 5 is less than or equal to -2 (True or False)
print("Is it less or equal?", 5 <= -2)
print("Is it less or equal?", 5 <= -2) 
