# Learn-Python-the-hard-way
My work on all the exercises
