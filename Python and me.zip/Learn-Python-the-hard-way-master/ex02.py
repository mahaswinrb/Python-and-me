#!/bin/python3
#!/usr/bin/env python3

# ex2: Comments and Pound Characters

@@ -10,4 +10,4 @@
# You can also use a comment to "disable" or comment out a piece of code:
# print("This won't run.")

print("This will run.")
print("This will run.") 
